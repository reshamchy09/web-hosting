﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ro",{title:"Informația elementului",dialogName:"Numele ferestrei de dialog",tabName:"Denumire de tab",elementId:"ID Element",elementType:"Tipul elementului"});