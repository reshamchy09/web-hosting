from django.urls import path
from . import views
from django.views.generic import TemplateView
urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('skills/', views.skills, name='skills'),
    path('services/', views.services, name='services'),
    path('projects/', views.projects, name='projects'),
    path('project/<int:pk>/', views.project_detail, name='project_detail'),
    path('experience/', views.experience, name='experience'),
    path('blog/', views.blog, name='blog'),
    path('blog/<slug:slug>/', views.blog_detail, name='blog_detail'),
    path('contact/', views.contact, name='contact'),
    path('download-resume/', views.download_resume, name='download_resume'),
    path('templates/', views.template_list, name='template_list'),
    path('templates/<int:pk>/preview/', views.template_preview, name='template_preview'),
     path('calculator/', views.services_page, name='mobile_app_calculator'),








  path('sitemap.xml', TemplateView.as_view(template_name="sitemap.xml", content_type='application/xml'), name='sitemap'),
      path('robots.txt', TemplateView.as_view(template_name="robots.txt", content_type='text/plain')),
    

]