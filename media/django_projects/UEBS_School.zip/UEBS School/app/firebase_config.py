# firebase_config.py
FIREBASE_CONFIG = {
    "apiKey": "AIzaSyC7cG8KemxvH2VveDO6DnIkYUpIl2exesU",
    "authDomain": "uebs-school.firebaseapp.com",
    "databaseURL": "https://uebs-school-default-rtdb.firebaseio.com/",  # Fixed URL format
    "projectId": "uebs-school",
    "storageBucket": "uebs-school.appspot.com",  # Fixed storage bucket URL
    "messagingSenderId": "740325293639",
    "appId": "1:740325293639:web:9c505c9a48dd8ccc55fb62",
    "measurementId": "G-T7YEBMNHBH"
}

